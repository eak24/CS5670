Ethan Keller	eak244
Tim Sears 	tds72


BUILDING
Build the program using 
	make clean
	make 


RUNNING THE EXECUTABLE
In the src directory, after running make, you should find a single binary "scissors".
Run it 
	./scissors



